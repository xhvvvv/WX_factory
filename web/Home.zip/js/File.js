
var s=new Array("我操劳","sad","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","sbbbb","sbbbb","sbbbb","sbbbb");
var s1=new Array("我操劳sss","sad","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","ssa","sbbbb","sbbbb","sbbbb","sbbbb");

//function addFileNamein(name){
//	document.getElementById("FileName").innerHtml("<li><a><span>"+name+"</span></a></li>");
//}
/*js原生增加节点*/
function addFileNameout(s){
	for(var i=0;i<s.length;i++){
		window.li = document.createElement("li");
		li.id="li-id"+s[i];
		li.className="li-class";
		var name=s[i];
		var html = "<a><span >"+name+"</span></a>";
		li.innerHTML = html;
		document.getElementById("FileName").appendChild(li);
	}
	
}
addFileNameout(s);


$("#FileName").delegate("li", "click", function () {
		var FileName1=$(this).text();
		alert(FileName1);
//    下面的方法只适用于删除一个节点的
//		var element=document.getElementsByClassName("li-class");alert(element);
//		element.parentNode.removeNode(element);
	var elements=document.getElementsByClassName("li-class");
	for(var i = elements.length - 1; i >= 0; i--) { 
	  elements[i].parentNode.removeChild(elements[i]); 
	}
		 addFileNameout(s1);
		s1=new Array("我操劳ss");
});


  
	




 

function loadingPersonchoosepage(){
//	插入节点的一种方式document.getElementsByClassName("personchoose").innerHTML = '<object type="text/html" data="index.html" width="100%" height="100%"></object>';
//	注意：需要在服务器环境下，否则会报跨域错误   document.getElementsByClassName("personchoose").innerHTML = personchoosepage.import.body.innerHTML;			
}
