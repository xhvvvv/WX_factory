/*通过jsq加载文档*/
$(function(){
    $("#menu-li5").click(function(){
		location.assign("File.html")
	});
});

function get(){
			alert(location);
		}
		
get();